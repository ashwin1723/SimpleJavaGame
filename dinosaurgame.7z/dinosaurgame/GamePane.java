package com.example.dinosaurgame;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GamePane extends Pane {
    public static final double HEIGHT = 50.0;
    public static final int WIDTH = 50;
    private final Dinosaur dinosaur;
    private final List<Obstacle> obstacles;
    private int score = 0;
    private boolean isJumping = false;
    private boolean isRunning = false;

    private final Timeline timeline;
    private final Random random = new Random();

    public GamePane() {
        dinosaur = new Dinosaur();
        obstacles = new ArrayList<>();

        getChildren().add(dinosaur);

        setOnKeyPressed(event -> {
            if (!isRunning)
                startGame();

            if (!isJumping) {
                dinosaur.jump();
                isJumping = true;
            }
        });

        timeline = new Timeline(new KeyFrame(Duration.millis(20), e -> {
            if (isRunning) {
                dinosaur.update();

                Iterator<Obstacle> iterator = obstacles.iterator();
                while (iterator.hasNext()) {
                    Obstacle obstacle = iterator.next();
                    obstacle.moveLeft();
                    if (obstacle.isPassed()) {
                        iterator.remove();
                        score++;
                    }

                    // Check for collision
                    if (isCollision(dinosaur, obstacle)) {
                        stopGame();
                    }
                }

                if (random.nextDouble() < 0.03) {
                    Obstacle obstacle = new Obstacle();
                    if (random.nextBoolean()) {
                        obstacle.setTranslateY(GamePane.HEIGHT - Obstacle.HEIGHT);
                    } else {
                        obstacle.setTranslateY(GamePane.HEIGHT - Obstacle.HEIGHT - Dinosaur.HEIGHT);
                    }
                    obstacles.add(obstacle);
                    getChildren().add(obstacle);
                }
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
    }

    private boolean isCollision(Dinosaur dino, Obstacle obstacle) {
        return dino.getBoundsInParent().intersects(obstacle.getBoundsInParent());
    }

    public void startGame() {
        dinosaur.resetJump();
        obstacles.clear();
        score = 0;
        isRunning = true;
        isJumping = false;
        timeline.play();
    }

    public void stopGame() {
        isRunning = false;
        timeline.stop();
        System.out.println("Game Over! Your Score: " + score);
    }
}

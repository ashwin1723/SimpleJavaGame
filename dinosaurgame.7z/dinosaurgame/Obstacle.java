package com.example.dinosaurgame;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Obstacle extends Rectangle {
    public static final double WIDTH = 30.0;
    public static final double HEIGHT = 20.0;
    private static final double SPEED = 5.0;
    private static final double INITIAL_X = GamePane.WIDTH;

    public Obstacle() {
        super(WIDTH, HEIGHT, Color.RED);
        setTranslateX(INITIAL_X);
    }

    public void moveLeft() {
        setTranslateX(getTranslateX() - SPEED);
    }

    public boolean isPassed() {
        return getTranslateX() + WIDTH < 0;
    }
}

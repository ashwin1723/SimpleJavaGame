package com.example.dinosaurgame;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class Dinosaur extends Rectangle {
    public static final int WIDTH = 40;
    public static final int HEIGHT = 40;
    private static final double JUMP_HEIGHT = 80;
    private static final double GRAVITY = 2.0;
    private static final double INITIAL_X = 100;

    private double jumpVelocity = 0.0;
    private boolean isJumping = false;

    public Dinosaur() {
        super(WIDTH, HEIGHT, Color.GREEN);
        setTranslateX(INITIAL_X);
        setTranslateY(GamePane.HEIGHT - HEIGHT);
    }

    public void jump() {
        if (!isJumping) {
            isJumping = true;
            jumpVelocity = -5.0;
        }
    }

    public void resetJump() {
        if (isJumping) {
            // Limit the jump height
            if (getTranslateY() <= GamePane.HEIGHT - Dinosaur.HEIGHT - JUMP_HEIGHT) {
                setTranslateY(GamePane.HEIGHT - Dinosaur.HEIGHT - JUMP_HEIGHT);
            }
        }
    }

    public void update() {
        if (isJumping) {
            setTranslateY(getTranslateY() + jumpVelocity);
            jumpVelocity += GRAVITY;

            if (getTranslateY() >= GamePane.HEIGHT - HEIGHT) {
                setTranslateY(GamePane.HEIGHT - HEIGHT);
                isJumping = false;
            }
        }
    }
}

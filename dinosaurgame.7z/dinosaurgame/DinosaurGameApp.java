package com.example.dinosaurgame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class DinosaurGameApp extends Application {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 400;

    @Override
    public void start(Stage primaryStage) {
        GamePane gamePane = new GamePane();

        Scene scene = new Scene(gamePane, WIDTH, HEIGHT);

        primaryStage.setTitle("Dinosaur Game");
        primaryStage.setScene(scene);
        primaryStage.show();

        gamePane.startGame();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
